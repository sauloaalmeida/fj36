package br.com.caelum.main;

import java.util.Scanner;

import javax.xml.ws.Endpoint;

import br.com.caelum.estoque.ws.v1.EstoqueWSV1;
import br.com.caelum.estoque.ws.v2.EstoqueWSV2;

public class RodaServicos {

	public static void main(String[] args) throws InterruptedException {

		final String URI_v1 = "http://localhost:8088/v1/EstoqueWS";
		final String URI_v2 = "http://localhost:8088/v2/EstoqueWS";
		
		Endpoint estoqueV1 = Endpoint.publish(URI_v1, new EstoqueWSV1());
		Endpoint estoqueV2 = Endpoint.publish(URI_v2, new EstoqueWSV2());
		
		System.out.println("*** Serviços rodando ***");
		System.out.println(URI_v1);
		System.out.println(URI_v2);

		System.out.println("Aperte Enter nesssa console para parar os serviços");
		
		Scanner scanner = new Scanner(System.in);
		
		if(scanner.hasNextLine()) {
			estoqueV1.stop();
			estoqueV2.stop();
			System.out.println("Serviços terminados");
		}
		
		scanner.close();
		
//		Thread.sleep(1000 * 3600);
	}
}
